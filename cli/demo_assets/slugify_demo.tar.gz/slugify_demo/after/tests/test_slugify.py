"""Tests for python-slugify."""

import sys
import pytest
from io import StringIO
from slugify import slugify, smart_truncate, PRE_TRANSLATIONS
from slugify.__main__ import parse_args, slugify_params, main


class TestSlugify:
    """Test slugify function."""
    
    def test_basic_ascii(self):
        assert slugify('Hello World') == 'hello-world'
    
    def test_unicode_cyrillic(self):
        assert slugify('Привет мир') == 'privet-mir'
    
    def test_unicode_chinese(self):
        result = slugify('你好世界')
        assert result  # Should produce some transliteration
    
    def test_unicode_arabic(self):
        result = slugify('مرحبا العالم')
        assert result  # Should produce some transliteration
    
    def test_allow_unicode(self):
        result = slugify('Hello 世界', allow_unicode=True)
        assert '世界' in result or 'shi-jie' in result.lower()
    
    def test_separator(self):
        assert slugify('Hello World', separator='_') == 'hello_world'
    
    def test_max_length(self):
        result = slugify('Hello World', max_length=5)
        assert len(result) <= 5
    
    def test_word_boundary(self):
        result = slugify('Hello World Test', max_length=10, word_boundary=True)
        assert len(result) <= 10
        assert not result.endswith('-w')  # Should not cut mid-word
    
    def test_stopwords(self):
        result = slugify('Hello the World', stopwords=['the'])
        assert 'the' not in result
        assert result == 'hello-world'
    
    def test_lowercase_false(self):
        result = slugify('Hello World', lowercase=False)
        assert 'H' in result or 'W' in result
    
    def test_replacements(self):
        result = slugify('Hello World', replacements=[['World', 'Universe']])
        assert 'universe' in result
    
    def test_regex_pattern(self):
        result = slugify('Hello123World', regex_pattern=r'[0-9]')
        assert '123' not in result
    
    def test_entities(self):
        result = slugify('&lt;Hello&gt;', entities=True)
        assert 'hello' in result
    
    def test_decimal_entities(self):
        result = slugify('&#72;ello', decimal=True)
        assert 'hello' in result
    
    def test_hexadecimal_entities(self):
        result = slugify('&#x48;ello', hexadecimal=True)
        assert 'hello' in result
    
    def test_pre_translations(self):
        assert '×' in PRE_TRANSLATIONS
        result = slugify('2×3')
        assert 'x' in result


class TestSmartTruncate:
    """Test smart_truncate function."""
    
    def test_no_truncate_when_short(self):
        assert smart_truncate('hello', 10) == 'hello'
    
    def test_simple_truncate(self):
        assert smart_truncate('hello-world', 5) == 'hello'
    
    def test_word_boundary(self):
        result = smart_truncate('hello-world-test', 12, word_boundary=True, separator='-')
        assert len(result) <= 12
    
    def test_max_length_zero(self):
        assert smart_truncate('hello', 0) == 'hello'


class TestCLI:
    """Test command-line interface."""
    
    def test_parse_args_basic(self):
        args = parse_args(['Hello', 'World'])
        assert args.text == ['Hello', 'World']
    
    def test_parse_args_stdin(self):
        args = parse_args(['--stdin'])
        assert args.stdin is True
    
    def test_parse_args_separator(self):
        args = parse_args(['--separator', '_', 'Hello'])
        assert args.separator == '_'
    
    def test_parse_args_stopwords(self):
        args = parse_args(['--stopwords', 'the', 'a', '--', 'Hello'])
        assert args.stopwords == ['the', 'a']
    
    def test_parse_args_replacements(self):
        args = parse_args(['--replacements', 'a->b', 'c->d'])
        assert args.replacements == ['a->b', 'c->d']
    
    def test_slugify_params_basic(self):
        args = parse_args(['Hello'])
        params = slugify_params(args)
        assert params['separator'] == '-'
        assert params['lowercase'] is True
    
    def test_slugify_params_replacements_valid(self):
        args = parse_args(['--replacements', 'a->b'])
        params = slugify_params(args)
        assert params['replacements'] == [['a', 'b']]
    
    def test_slugify_params_replacements_invalid(self, capsys):
        args = parse_args(['--replacements', 'invalid'])
        with pytest.raises(SystemExit) as exc_info:
            slugify_params(args)
        assert exc_info.value.code == 2
        captured = capsys.readouterr()
        assert 'Replacements must be of the form: ORIGINAL->REPLACED' in captured.err
    
    def test_main_basic(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', 'Hello', 'World'])
        main()
        captured = capsys.readouterr()
        assert 'hello-world' in captured.out
    
    def test_main_stdin(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', '--stdin'])
        monkeypatch.setattr(sys, 'stdin', StringIO('Hello World'))
        main()
        captured = capsys.readouterr()
        assert 'hello-world' in captured.out
    
    def test_main_stdin_with_text_error(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', '--stdin', 'Hello'])
        with pytest.raises(SystemExit) as exc_info:
            main()
        assert exc_info.value.code == 2
        captured = capsys.readouterr()
        assert 'Input strings and --stdin cannot work together' in captured.err
    
    def test_main_stopwords(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', '--stopwords', 'the', '--', 'Hello', 'the', 'World'])
        main()
        captured = capsys.readouterr()
        assert 'hello-world' in captured.out
        assert 'the' not in captured.out
    
    def test_main_replacements(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', '--replacements', 'World->Universe', '--', 'Hello', 'World'])
        main()
        captured = capsys.readouterr()
        assert 'universe' in captured.out
    
    def test_main_replacements_invalid(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, 'argv', ['slugify', '--replacements', 'invalid'])
        with pytest.raises(SystemExit) as exc_info:
            main()
        assert exc_info.value.code == 2
        captured = capsys.readouterr()
        assert 'Replacements must be of the form: ORIGINAL->REPLACED' in captured.err
