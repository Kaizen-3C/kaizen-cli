"""Command-line interface for slugify."""

import sys
import argparse
from typing import Dict, Any
from slugify.slugify import slugify


def slugify_params(args: argparse.Namespace) -> Dict[str, Any]:
    """Convert parsed arguments to slugify function parameters."""
    params = {
        'entities': args.entities,
        'decimal': args.decimal,
        'hexadecimal': args.hexadecimal,
        'max_length': args.max_length,
        'word_boundary': args.word_boundary,
        'separator': args.separator,
        'lowercase': not args.no_lower,
        'allow_unicode': args.allow_unicode,
    }
    
    if args.stopwords:
        params['stopwords'] = args.stopwords
    
    if args.replacements:
        replacements = []
        for repl in args.replacements:
            if '->' not in repl:
                sys.stderr.write('Replacements must be of the form: ORIGINAL->REPLACED\n')
                sys.exit(2)
            parts = repl.split('->', 1)
            replacements.append(parts)
        params['replacements'] = replacements
    
    if args.regex_pattern:
        params['regex_pattern'] = args.regex_pattern
    
    return params


def parse_args(args=None):
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description='Convert text to URL-friendly slugs',
        prog='slugify'
    )
    
    parser.add_argument(
        'text',
        nargs='*',
        help='Text to slugify'
    )
    
    parser.add_argument(
        '--stdin',
        action='store_true',
        help='Read text from stdin'
    )
    
    parser.add_argument(
        '--entities',
        action='store_true',
        default=True,
        help='Decode HTML entities (default: True)'
    )
    
    parser.add_argument(
        '--decimal',
        action='store_true',
        default=True,
        help='Decode decimal HTML entities (default: True)'
    )
    
    parser.add_argument(
        '--hexadecimal',
        action='store_true',
        default=True,
        help='Decode hexadecimal HTML entities (default: True)'
    )
    
    parser.add_argument(
        '--max-length',
        type=int,
        default=0,
        help='Maximum length of slug (default: 0, no limit)'
    )
    
    parser.add_argument(
        '--word-boundary',
        action='store_true',
        help='Truncate at word boundaries'
    )
    
    parser.add_argument(
        '--separator',
        default='-',
        help='Separator character (default: -)'
    )
    
    parser.add_argument(
        '--no-lower',
        action='store_true',
        help='Do not convert to lowercase'
    )
    
    parser.add_argument(
        '--stopwords',
        nargs='+',
        help='Words to remove from slug'
    )
    
    parser.add_argument(
        '--replacements',
        nargs='+',
        help='Custom replacements in the form ORIGINAL->REPLACED'
    )
    
    parser.add_argument(
        '--regex-pattern',
        help='Custom regex pattern for disallowed characters'
    )
    
    parser.add_argument(
        '--allow-unicode',
        action='store_true',
        help='Preserve Unicode characters'
    )
    
    return parser.parse_args(args)


def main():
    """Main entry point for CLI."""
    args = parse_args()
    
    # Get input text
    if args.stdin:
        if args.text:
            sys.stderr.write('Input strings and --stdin cannot work together\n')
            sys.exit(2)
        text = sys.stdin.read().strip()
    elif args.text:
        text = ' '.join(args.text)
    else:
        text = ''
    
    # Get slugify parameters
    params = slugify_params(args)
    
    # Generate and print slug
    slug = slugify(text, **params)
    print(slug)


if __name__ == '__main__':
    main()
