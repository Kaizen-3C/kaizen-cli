"""Core slugify implementation."""

import re
import html
from typing import Iterable

try:
    from text_unidecode import unidecode
except ImportError:
    try:
        from unidecode import unidecode
    except ImportError:
        def unidecode(text):
            return text

DEFAULT_SEPARATOR = '-'

PRE_TRANSLATIONS = {
    '×': 'x',
    '@': 'at',
    '©': 'c',
    '®': 'r',
    '™': 'tm',
    '℠': 'sm',
    '№': 'no',
    '℃': 'c',
    '℉': 'f',
    '°': '',
    '€': 'euro',
    '£': 'pound',
    '¥': 'yen',
    '₹': 'inr',
    '$': 'dollar',
    '¢': 'cent',
    '₽': 'rub',
    '₴': 'uah',
    '₩': 'won',
    '₪': 'nis',
    '฿': 'baht',
    '₫': 'dong',
    '₦': 'ngn',
    '₨': 'rs',
    '₱': 'peso',
    '₡': 'colon',
    '₵': 'cedi',
    '₲': 'guarani',
    '₸': 'tenge',
    '₺': 'lira',
    '₼': 'manat',
    '₾': 'lari',
}


def smart_truncate(text: str, max_length: int, word_boundary: bool = False, separator: str = DEFAULT_SEPARATOR, save_order: bool = False) -> str:
    """Truncate text to max_length, optionally respecting word boundaries."""
    if max_length <= 0 or len(text) <= max_length:
        return text
    
    if word_boundary:
        truncated = text[:max_length].rsplit(separator, 1)[0]
        return truncated if truncated else text[:max_length]
    
    return text[:max_length]


def slugify(
    text: str,
    entities: bool = True,
    decimal: bool = True,
    hexadecimal: bool = True,
    max_length: int = 0,
    word_boundary: bool = False,
    separator: str = DEFAULT_SEPARATOR,
    save_order: bool = False,
    stopwords: Iterable[str] = (),
    regex_pattern: str | None = None,
    lowercase: bool = True,
    replacements: Iterable[Iterable[str]] = (),
    allow_unicode: bool = False,
) -> str:
    """Convert text to a URL-friendly slug.
    
    Args:
        text: Input string to slugify
        entities: Decode HTML entities
        decimal: Decode decimal HTML entities
        hexadecimal: Decode hexadecimal HTML entities
        max_length: Maximum length of the slug (0 = no limit)
        word_boundary: Truncate at word boundaries
        separator: Character to use as separator
        save_order: Preserve order when truncating
        stopwords: Words to remove from the slug
        regex_pattern: Custom regex pattern for disallowed characters
        lowercase: Convert to lowercase
        replacements: Custom character replacements [[original, replacement], ...]
        allow_unicode: Preserve Unicode characters instead of transliterating
    
    Returns:
        URL-friendly slug string
    """
    # Decode HTML entities
    if entities:
        text = html.unescape(text)
    if decimal:
        text = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), text)
    if hexadecimal:
        text = re.sub(r'&#[xX]([0-9a-fA-F]+);', lambda m: chr(int(m.group(1), 16)), text)
    
    # Apply custom replacements first
    for replacement in replacements:
        if len(replacement) >= 2:
            text = text.replace(replacement[0], replacement[1])
    
    # Apply pre-translations
    for original, replacement in PRE_TRANSLATIONS.items():
        text = text.replace(original, replacement)
    
    # Transliterate to ASCII unless allow_unicode is True
    if not allow_unicode:
        text = unidecode(text)
    
    # Convert to lowercase if requested
    if lowercase:
        text = text.lower()
    
    # Replace unwanted characters
    if allow_unicode:
        # Keep Unicode word characters, digits, and whitespace
        if regex_pattern:
            text = re.sub(regex_pattern, ' ', text)
        else:
            text = re.sub(r'[^\w\s-]', ' ', text, flags=re.UNICODE)
    else:
        # ASCII mode
        if regex_pattern:
            text = re.sub(regex_pattern, ' ', text)
        else:
            text = re.sub(r'[^a-z0-9\s-]', ' ', text)
    
    # Normalize whitespace and replace with separator
    text = re.sub(r'[-\s]+', separator, text)
    
    # Remove stopwords
    if stopwords:
        stopwords_set = set(stopwords)
        words = text.split(separator)
        words = [word for word in words if word not in stopwords_set]
        text = separator.join(words)
    
    # Strip leading/trailing separators
    text = text.strip(separator)
    
    # Truncate to max_length
    if max_length > 0:
        text = smart_truncate(text, max_length, word_boundary, separator, save_order)
        text = text.strip(separator)
    
    return text
