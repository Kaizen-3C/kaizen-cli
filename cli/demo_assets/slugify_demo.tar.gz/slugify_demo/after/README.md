Recomposed Python port of python-slugify. See ../before/ for the original.
