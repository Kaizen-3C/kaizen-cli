# ADR-python-slugify-decomposed: ADR-python-slugify-decomposed

## Status
Accepted

## Context
python-slugify is a library that converts Unicode strings into URL-friendly slugs. It handles diverse character sets (Cyrillic, Chinese, Arabic, emoji, etc.) by transliterating them to ASCII or preserving Unicode, while offering extensive customization for separators, stopwords, length constraints, and character filtering. The library also provides a CLI tool for command-line slug generation.

## Decision Drivers
- Need to handle Unicode text from multiple languages and scripts
- Support both ASCII transliteration and Unicode preservation modes
- Provide flexible text processing options (stopwords, replacements, truncation)
- Offer both programmatic API and command-line interface
- Support multiple Unicode decoding backends (text-unidecode vs Unidecode)
- Maintain backward compatibility across Python versions 3.10+

## Decision
- Use text-unidecode as the default Unicode decoding library  _(evidence: `setup.py:14`)_
- Provide Unidecode as an optional extra dependency via python-slugify[unidecode]  _(evidence: `setup.py:15`)_
- Require Python >= 3.10  _(evidence: `setup.py:11`)_
- Expose a console_scripts entry point 'slugify' that invokes slugify.__main__:main  _(evidence: `setup.py:83`)_
- Support HTML entity decoding (entities, decimal, hexadecimal) as boolean flags  _(evidence: `README.md:40-42`)_
- Implement max_length truncation with optional word_boundary and save_order modes  _(evidence: `README.md:43-46`)_
- Allow custom separator strings (default '-')  _(evidence: `README.md:45`)_
- Support stopwords filtering via an iterable of strings  _(evidence: `README.md:47`)_
- Provide regex_pattern parameter for custom disallowed-character filtering  _(evidence: `README.md:48`)_
- Support case-sensitive slugs via lowercase boolean flag  _(evidence: `README.md:49`)_
- Allow pre-transliteration replacements via an iterable of [original, replacement] pairs  _(evidence: `README.md:50`)_
- Provide allow_unicode flag to preserve Unicode characters instead of transliterating to ASCII  _(evidence: `README.md:51`)_
- Include a smart_truncate utility function for length-aware truncation  _(evidence: `test.py:9`)_
- Define PRE_TRANSLATIONS constant for special character mappings  _(evidence: `test.py:7`)_
- Implement CLI argument parsing via parse_args and slugify_params functions  _(evidence: `test.py:10`)_

## Consequences

### Positive
- Supports a wide range of Unicode scripts and languages out of the box  _(evidence: `test.py:34-60`)_
- Provides extensive customization options for slug generation  _(evidence: `README.md:38-69`)_
- Offers both library and CLI interfaces for flexibility  _(evidence: `setup.py:83`)_
- Allows users to choose between GPL-licensed Unidecode and Artistic/GPL text-unidecode  _(evidence: `README.md:15-17`)_

### Negative
- Dependency on external Unicode decoding libraries introduces licensing complexity  _(evidence: `README.md:202-204`)_
- Regex_pattern parameter requires careful coordination with separator to avoid conflicts  _(evidence: `test.py:216-224`)_

### Neutral
- The library uses tox for testing against multiple Python versions and both unidecode backends
- Coverage target is set to 97% minimum

## Key Identifiers

| Name | Kind | File | Signature / Attributes |
|------|------|------|------------------------|
| `slugify` | function | `README.md` | `def slugify(text: str, entities: bool = True, decimal: bool = True, hexadecimal: bool = True, max_length: int = 0, word_boundary: bool = False, separator: str = DEFAULT_SEPARATOR, save_order: bool = False, stopwords: Iterable[str] = (), regex_pattern: str \| None = None, lowercase: bool = True, replacements: Iterable[Iterable[str]] = (), allow_unicode: bool = False) -> str:` |
| `smart_truncate` | function | `test.py` |  |
| `PRE_TRANSLATIONS` | constant | `test.py` |  |
| `parse_args` | function | `test.py` |  |
| `slugify_params` | function | `test.py` |  |
| `main` | function | `setup.py` |  |

### Load-bearing signatures / attributes

Implementations MUST match these exactly.

- **`slugify`** (function): `def slugify(text: str, entities: bool = True, decimal: bool = True, hexadecimal: bool = True, max_length: int = 0, word_boundary: bool = False, separator: str = DEFAULT_SEPARATOR, save_order: bool = False, stopwords: Iterable[str] = (), regex_pattern: str | None = None, lowercase: bool = True, replacements: Iterable[Iterable[str]] = (), allow_unicode: bool = False) -> str:`

## Output Contracts

**Load-bearing**: implementations must reproduce these exactly.

### `slugify [OPTIONS] [TEXT...]`

**stdout format:**
```
<slug>
(single line containing the generated slug)
```

**stderr format:**
```
Error messages for invalid arguments (e.g. 'Replacements must be of the form: ORIGINAL->REPLACED')
```

**exit codes:** 0 on success, 2 on argument error

**side effects:** Reads from stdin when --stdin flag is passed

**evidence:** `test.py:621-646`

### `slugify --stdin`

**stdout format:**
```
<slug>
(slug generated from stdin input)
```

**stderr format:**
```
Error if both --stdin and positional text arguments are provided: 'Input strings and --stdin cannot work together'
```

**exit codes:** 0 on success, 2 on usage error

**side effects:** Reads text from stdin

**evidence:** `test.py:636-646`

### `slugify --stopwords WORD [WORD...] -- TEXT...`

**stdout format:**
```
<slug>
(slug with stopwords removed)
```

**exit codes:** 0 on success

**side effects:** None

**evidence:** `test.py:648-653`

### `slugify --replacements ORIG->REPL [ORIG->REPL...] -- TEXT...`

**stdout format:**
```
<slug>
(slug with custom replacements applied)
```

**stderr format:**
```
Error if replacement format is invalid: 'Replacements must be of the form: ORIGINAL->REPLACED'
```

**exit codes:** 0 on success, 2 on format error

**side effects:** None

**evidence:** `test.py:615-624`
